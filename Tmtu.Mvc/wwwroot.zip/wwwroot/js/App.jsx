function App() {
    return (
        <div>
            <h1>Hello from React in MVC!</h1>
            <p>This is a React component rendered inside a cshtml page.</p>
        </div>
    );
}
